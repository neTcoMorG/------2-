import { Box } from "@chakra-ui/react";


export default function Footer () {
    return (
        <Box w={'100%'} h={'200px'} bgColor={'black'}>
            Hello, world
        </Box>
    )  
}